const TROMBINOSCOP_USERS = [{ // déclaration de la constante "TROMBINOSCOP_USERS" en lui donnant la valeur du tableau d'objets ci-après
	name: "Rael CALITRO",
	pict: "image001.jpg",
}, {
	name: "Pierre GUILLEC",
	pict: "image002.jpg",
}, {
	name: "Ala-Eddine BEJAOUI",
	pict: "image003.jpg",
}, {
	name: "Aleksandra SPASOYEVICH",
	pict: "image004.jpg",
}, {
	name: "Tunga NATSAGDORJ",
	pict: "image005.jpg",
}, {
	name: "Loïc CRAMPÉ",
	pict: "image006.jpg",
}, {
	name: "Thomas PALUMBO",
	pict: "image007.jpg",
},{
	name: "Quentin CNUDDE",
	pict: "image008.jpg",
},{
	name: "Tanguy LELONG",
	pict: "image009.jpg",
},{
	name: "Karima VERUCCHI",
	pict: "image010.jpg",
},{
	name: "Julia BORTOT",
	pict: "image011.jpg",
},{
	name: "Alexandre DAVID",
	pict: "image012.jpg",
},{
	name: "Anissa OUESLATI",
	pict: "image013.jpg",
},{
	name: "Alban VEUX",
	pict: "image014.jpg",
},{
	name: "Théo RIVAL",
	pict: "image015.jpg",
},{
	name: "Dylan BOUAROUDJ",
	pict: "image016.jpg",
},{
	name: "Anabela ALVES MIRANDA",
	pict: "image017.jpg",
},{
	name: "Marine TESOLIN",
	pict: "image018.jpg",
},{
	name: "Nada BACIME",
	pict: "image019.jpg",
},{
	name: "Maria GOMES DIAS",
	pict: "image020.jpg",
},{
	name: "Loïc BOUKAYA",
	pict: "image021.jpg",
},{
	name: "Florent MULLER",
	pict: "image022.jpg",
},{
	name: "Victoria GHIRARDI",
	pict: "image023.jpg",
},{
	name: "George DOS SANTOS",
	pict: "image024.jpg",
},{
	name: "Térence FERUT",
	pict: "image025.jpg",
},{
	name: "Mickael",
	pict: "image026.jpg",
},{
	name: "Micka",
	pict: "image027.jpg",
},{
	name: "PROMO SIMPLON AU COMPLET",
	pict: "image028.jpg",
},{
	name: "PROMO SIMPLON AU COMPLET ",
	pict: "image029.jpg",
}];
